#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdbm.h>

int
main(int argc, char *argv[])
{
    GDBM_FILE dbf;
    int rc;
    datum key, value;

    if ( 2 != argc ) {
        fprintf(stderr, "Usage: %s key2read, argc=%d\n", argv[0], argc);
        exit(1);
    }
    dbf = gdbm_open("mydata.db", 0, GDBM_READER, 0, NULL);
    if (dbf == NULL) {
        printf("Can not open database\n: %s\n", gdbm_strerror(gdbm_errno));
    }
    
    key.dptr = argv[1];
    key.dsize = strlen(argv[1]);

    value = gdbm_fetch(dbf, key);
    if (value.dptr == NULL) {
        printf("Record not found\n");
    } else {
        printf("Record found(%d): %s\n", value.dsize, value.dptr);
        free(value.dptr);
    }

    gdbm_close(dbf);
    return 0;
}


