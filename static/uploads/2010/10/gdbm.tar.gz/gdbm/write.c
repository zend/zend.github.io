#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdbm.h>

int
main(int argc, char *argv[])
{
    GDBM_FILE dbf;
    int rc;
    datum key, value;

    if ( 3 != argc ) {
        fprintf(stderr, "Usage: %s key value\n", argv[0]);
        exit(1);
    }
    dbf = gdbm_open("mydata.db", 0, GDBM_WRITER, 0, NULL);
    if (dbf == NULL) {
        printf("Can not open database\n: %s\n", gdbm_strerror(gdbm_errno));
    }
    
    key.dptr = argv[1];
    key.dsize = strlen(argv[1]);

    value.dptr = argv[2];
    value.dsize = strlen(argv[2]);

    rc = gdbm_store(dbf, key, value, GDBM_INSERT);
    if (rc != 0) {
        printf("Can not store record: %s\n", gdbm_strerror(gdbm_errno));
    }

    gdbm_close(dbf);
}


