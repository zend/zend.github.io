#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>

int 
main(int argc, char *argv[])
{
	unsigned long src_len = 0, dst_len = 0, out_len = 0;
	char dst_buf[1024], out_buf[1024];
	char *src_buf;
	int rc;

	if (2 != argc) {
		fprintf(stderr, "Usage: %s str2compress\n", argv[0]);
		exit(1);
	}

	src_buf = argv[1];
	src_len = strlen(src_buf);
	dst_len = sizeof(dst_buf);

	if (dst_len < src_len) {
		fprintf(stderr, "Data too long\n");
		exit(2);
	}

	rc = compress(dst_buf, &dst_len, src_buf, src_len);
	if (rc == Z_OK) {
		dst_buf[dst_len] = '\0';
		printf("dst_len=%u, compressed data=%s\n", dst_len, dst_buf);
	} else {
		printf("rc=%d\n");
		printf("compress error=%s\n", zError(rc));
		exit(3);
	}

	out_len = sizeof(out_buf);
	rc = uncompress(out_buf, &out_len, dst_buf, dst_len + 1);
	if (rc == Z_OK) {
		dst_buf[dst_len] = '\0';
		printf("dst_len=%u, uncompressed data=%s\n", out_len, out_buf);
	} else {
		printf("rc=%d\n");
		printf("uncompress error=%s\n", zError(rc));
		exit(4);
	}

	return 0;
}


