#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdbm.h>
#include <zlib.h>

int
main(int argc, char *argv[])
{
    GDBM_FILE dbf;
    int rc;
    datum key, value;

	unsigned long zlen;
	char zbuf[1024];

    if ( 3 != argc ) {
        fprintf(stderr, "Usage: %s key value\n", argv[0]);
        exit(1);
    }
    dbf = gdbm_open("zdata.db", 0, GDBM_WRITER, 0, NULL);
    if (dbf == NULL) {
        printf("Can not open database\n: %s\n", gdbm_strerror(gdbm_errno));
    }
    
    key.dptr = argv[1];
    key.dsize = strlen(argv[1]);

	zlen = sizeof(zbuf);
	rc = compress(zbuf, &zlen, argv[2], strlen(argv[2]));
	if (rc != Z_OK) {
		fprintf(stderr, "data error: %s\n", zError(rc));
		exit(rc);
	}
	zbuf[zlen] = '\0';

    value.dptr = zbuf;
    value.dsize = zlen + 1;

    rc = gdbm_store(dbf, key, value, GDBM_INSERT);
    if (rc != 0) {
        printf("Can not store record: %s\n", gdbm_strerror(gdbm_errno));
    }

    gdbm_close(dbf);
}


