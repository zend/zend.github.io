#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdbm.h>
#include <zlib.h>

int
main(int argc, char *argv[])
{
    GDBM_FILE dbf;
    int rc;
    datum key, value;
	unsigned long zlen = 0;
	unsigned char zbuf[1024];

    if ( 2 != argc ) {
        fprintf(stderr, "Usage: %s key, argc=%d\n", argv[0], argc);
        exit(1);
    }

    dbf = gdbm_open("zdata.db", 0, GDBM_READER, 0, NULL);
    if (dbf == NULL) {
        printf("Can not open database\n: %s\n", gdbm_strerror(gdbm_errno));
    }
    
    key.dptr = argv[1];
    key.dsize = strlen(argv[1]);

    value = gdbm_fetch(dbf, key);
    if (value.dptr == NULL) {
        printf("Record not found\n");
    } else {
		zlen = sizeof(zbuf);
		rc = uncompress(zbuf, &zlen, value.dptr, value.dsize);
		if (rc != Z_OK) {
			fprintf(stderr, "data error: %s\n", zError(rc));
			exit(rc);
		}

		zbuf[zlen] = '\0';
        printf("Record found(%d): %s\n", zlen, zbuf);
        free(value.dptr);
    }

    gdbm_close(dbf);
    return 0;
}


