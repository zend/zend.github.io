<?php
define('PROXY_DEBUG', true);
echo '<textarea id="" rows="50" cols="120">';
//echo get_content_via_proxy("http://www.example.com/css/global11.css");
echo get_headers_via_proxy("http://www.example.com/css/global11.css");
echo '</textarea>';

function get_content_via_proxy($url) {
	$ip = "10.6.234.33";
	$port = 8080;

	$fp = fsockopen($ip, $port);
	if (!$fp) return false;

	//$arr = parse_url($url);
	$cmds  = "GET $url\r\n";
	$cmds .= "Host: $ip\r\n\r\n";

	fputs($fp, $cmds);
	$data = "";

	while(!feof($fp)) $data .= fgets($fp, 4096);

	fclose($fp);

	$real_data = $data;//substr($data, strpos($data, "\r\n\r\n") + 4);

	return $real_data;
}

/**
mikeliang@C2C_206_51_sles10sp1:~> telnet 10.6.234.33 8080
Trying 10.6.234.33...
Connected to 10.6.234.33.
Escape character is '^]'.
CONNECT 10.6.234.33:8080 HTTP/1.0
Host: 10.6.234.33:8080

HTTP/1.1 200 Connection established

HEAD http://www.example.com/css/global.css HTTP/1.1
Host: www.example.com
Proxy-Connection: Keep-Alive

HTTP/1.1 200 OK
Server: NWS-imgcache
Date: Wed, 17 Nov 2010 04:28:21 GMT
Expires: Wed, 17 Nov 2010 05:28:21 GMT
Cache-Control: max-age=3600
Last-Modified: Mon, 08 Nov 2010 11:01:49 GMT
Content-Type: text/css
Content-Length: 29703
X-Cache-Lookup: MISS from proxy:8080

Connection closed by foreign host.
mikeliang@C2C_206_51_sles10sp1:~>

*/
function get_headers_via_proxy($url) {
	$proxy_ip = "10.6.234.33";
	$proxy_port = 8080;

	$fp = fsockopen($proxy_ip, $proxy_port);
	if (!$fp) return false;

	$cmds  = "CONNECT $proxy_ip:$proxy_port HTTP/1.0\r\n";
	$cmds .= "Host: $proxy_ip:$proxy_port\r\n";
	$cmds .= "\r\n";

	if (defined('PROXY_DEBUG')) {
		echo $cmds;
		flush();
	}

	fputs($fp, $cmds);
	$response = fgets($fp, 64);

	if (strpos($response, '200') !== false) {
		// connected
		if (defined('PROXY_DEBUG')) {
			echo 'Response: ' .$response."\r\n";
			flush();
		}

		$arr = parse_url($url);
		
		$cmds  = "HEAD $url HTTP/1.1\r\n";
		$cmds .= "Host: {$arr['host']}\r\n";
		$cmds .= "Accept: */*\r\n";
		//$cmds .= "Proxy-Connection: Keep-Alive\r\n";
		$cmds .= "\r\n";

		if (defined('PROXY_DEBUG')) {
			echo $cmds;
			flush();
		}

		fputs($fp, $cmds);

		$data = "";
		while(!feof($fp) && false === strpos($data, "\r\n\r\n")) $data .= fgets($fp, 4096);

		fclose($fp);

		return $data;
	} else {
		fclose($fp);
		if (defined('PROXY_DEBUG')) {
			echo 'ERROR: '.$response;
			flush();
		}
		return false;
	}
}
