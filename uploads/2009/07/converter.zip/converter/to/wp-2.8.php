<?php
/* Name: WordPress 2.8 */
define('ABSPATH', dirname(__FILE__) . '/../hack/');
$path = 'D:\www\seaprince.cn';

global $path;
include $path . "/wp-config.php";
$db2 = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
mysql_query("SET NAMES '".DB_CHARSET."'", $db2);

class BlogTo {
	var $uid_map = array();	// user id map. old_id => new_id
	var $cid_map = array();	// category id map. old_id => new_id
	function BlogTo() {
	}
	function setSettings($settings) {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$obj = new stdClass();
		$sql = "UPDATE {$dbname}.{$table_prefix}options SET option_value='{$settings->name}' WHERE option_name='blogname'";
		$result = mysql_query($sql, $db2);
		$rows = mysql_affected_rows($db2);
		////////
		$sql = "UPDATE {$dbname}.{$table_prefix}options SET option_value='{$settings->description}' 
				WHERE option_name='blogdescription'";
		$result = mysql_query($sql, $db2);
		$rows2 = mysql_affected_rows();

		return $rows.$rows2;
	}
	function setUsers($users) {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$i = 0;
		foreach($users as $user) {
			$user = $this->escape($user);
			$sql = "INSERT INTO {$dbname}.{$table_prefix}users 
					SET user_login='{$user->username}',
					user_pass='{$user->password}' ,
					user_email='{$user->email}' ,
					user_registered='{$user->reg_date}' ";
			$result = mysql_query($sql, $db2);
			$this->uid_map['oldid_'.$user->uid] = mysql_insert_id($db2);
			if($result) $i++;
		}
		return $i;
	}
	function setCates($cates) {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$i = 0;
		$cid_map = array();
		foreach($cates as $v) {
			$v = $this->escape($v);
			$sql = "INSERT INTO {$dbname}.{$table_prefix}terms 
					SET name='{$v->name}',
					slug='{$v->url}' ";
			$result = mysql_query($sql, $db2);
			// push to the map
			$cid_map['oldid_'.$v->oldid] = mysql_insert_id($db2);
			$sql = "INSERT INTO {$dbname}.{$table_prefix}term_taxonomy
					SET term_id=last_insert_id(), 
					taxonomy='category' ";
			$result2 = mysql_query($sql, $db2);
			if(!$result2) $this->halt($sql);
			if($result && $result2) $i++;
		}
		$this->cid_map = $cid_map;
		return $i;
	}
	function setArticle($article) {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$v = &$article;
		$uid = $this->uid_map['oldid_'.$v->uid];
		$post_status = $v->allow_view ? 'publish' : 'private';
		$comment_status = $v->allow_comment ? 'open' : 'closed';
		$ping_status = $v->allow_trackback ? 'open' : 'closed';
		$v = $this->escape($v);
		$sql = "INSERT INTO {$dbname}.{$table_prefix}posts 
				SET post_author='{$uid}',
				post_date='{$v->postdate}',
				post_date_gmt='{$v->postdate}',
				post_content='{$v->content}',
				post_title='{$v->title}',
				post_excerpt='{$v->excerpt}',
				post_status='{$post_status}',
				comment_status='{$comment_status}',
				ping_status='{$v->allow_trackback}',
				post_password='{$v->password}',
				post_name='{$v->url}',
				post_type='post',
				comment_count='{$v->comment_count}'
				";
		$result = mysql_query($sql, $db2);
		// store the post id for comments and trackbacks
		global $post_id;
		$post_id = mysql_insert_id($db2);
		if(!$result) $this->halt($sql);
		// category
		$cid = intval($this->cid_map['oldid_'.$v->cid]);
		$sql = "INSERT INTO {$dbname}.{$table_prefix}term_relationships
				SET object_id=last_insert_id(),
				term_taxonomy_id=$cid,
				term_order=0
				";
		$result = mysql_query($sql, $db2);
		if(!$result) $this->halt($sql);
		// comments
	}
	function setComments($comments) {
		global $db2, $table_prefix, $post_id;
		$dbname = DB_NAME;
		$post_id = intval($post_id);
		foreach($comments as $k=>$v) {
			$isEmail = preg_match("/^[0-9a-z\-_\.]+@[0-9a-z\-\.]+\.[a-z]{2,6}$/", $v->url);
			$email = $isEmail ? $v->url : 'anony@mo.us';
			$url = !$isEmail ? $v->url : '';
			$v = $this->escape($v);
			$sql = "INSERT INTO {$dbname}.{$table_prefix}comments 
					SET 
					comment_post_ID=$post_id,
					comment_author='{$v->author}',
					comment_author_email='$email',
					comment_author_url='$url',
					comment_author_IP='{$v->ip}',
					comment_date='{$v->time}',
					comment_date_gmt='{$v->time}',
					comment_content='{$v->content}',
					comment_approved='{$v->visible}'
					";
			$result = mysql_query($sql);
			if(!$result) $this->halt($sql);
		}
	}
	function setTrackbacks($trackbacks) {
		return true;
	}
	function setLinks($links) {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$i = 0;
		foreach($links as $k=>$v) {
			$v = $this->escape($v);
			$sql = "INSERT INTO {$dbname}.{$table_prefix}links 
					SET 
					link_url='{$v->url}',
					link_name='{$v->name}',
					link_description='{$v->desc}',
					link_visible='{$v->visible}'
					";
			$result = mysql_query($sql);
			if(!$result) $this->halt($sql);
			$i ++;
		}
		return $i;
	}

	function updateCateCache() {
		global $db2, $table_prefix;
		$dbname = DB_NAME;
		$sql = "update {$dbname}.{$table_prefix}term_taxonomy set `count`=(
				select count(*) from {$dbname}.{$table_prefix}term_relationships 
				where {$dbname}.{$table_prefix}term_relationships.`term_taxonomy_id` = {$dbname}.{$table_prefix}term_taxonomy.`term_taxonomy_id`
				)";
		$result = mysql_query($sql);
	}

	function escape($obj) {
		foreach($obj as $k=>$v) {
			$obj->$k = mysql_real_escape_string($v);
		}
		return $obj;
	}

	function halt($sql) {
		var_dump($sql);
		var_dump(mysql_error());
		exit;
	}
}