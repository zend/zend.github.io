<?php
/* Name: SaBlog-X 2.0 */
$path = 'D:\www\prj\seaprince.cn';

include $path . "/config.php";
$db = mysql_connect($servername, $dbusername, $dbpassword);
mysql_select_db($dbname, $db);
mysql_query("SET NAMES '$dbcharset'", $db);

class BlogFrom {
	function BlogFrom() {
	}
	function getSettings() {
		global $db, $db_prefix, $dbname;
		$obj = new stdClass();
		$sql = "SELECT value FROM {$dbname}.{$db_prefix}settings WHERE title='name'";
		$result = mysql_query($sql, $db);
		if (!$result) exit(mysql_error());
		$row = mysql_fetch_row($result);
		$obj->name = $row[0];
		////////
		$sql = "SELECT value FROM {$dbname}.{$db_prefix}settings WHERE title='description'";
		$result = mysql_query($sql, $db);
		if (!$result) exit(mysql_error());
		$row = mysql_fetch_row($result);
		$obj->description = $row[0];

		return $obj;
	}
	function getUsers() {
		global $db, $db_prefix, $dbname;
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}users";
		$result = mysql_query($sql, $db);
		$arr = array();
		while($row = mysql_fetch_object($result)) {
			$arr[] = (object) array(
				'uid'		=> $row->userid,
				'username'	=> $row->username,
				'password'	=> $row->password,
				'email'		=> $row->url ? $row->url : strtolower($row->username).'@mail.com',
				'reg_date'	=> date('Y-m-d H:i:s', $row->regdateline)
			);
		}
		return $arr;
	}
	function getCates() {
		global $db, $db_prefix, $dbname;
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}categories ORDER BY displayorder ASC";
		$result = mysql_query($sql, $db);
		$arr = array();
		while($row = mysql_fetch_object($result)) {
			$arr[] = (object) array(
				'oldid'	=> $row->cid,
				'name'	=> $row->name,
				'count'	=> $row->articles,
				'url'	=> $row->url
			);
		}
		return $arr;
	}
	function getNextArticle() {
		global $db, $db_prefix, $dbname;
		static $current_id = 0;
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}articles WHERE articleid>$current_id LIMIT 1";
		$result = mysql_query($sql, $db);
		if(!$result) return false;
		$obj = mysql_fetch_object($result);
		if(!$obj) return false;
		$current_id = $obj->articleid;
		return (object) array(
			'oldid'		=> $obj->articleid,
			'cid'		=> $obj->cid,
			'uid'		=> $obj->uid,
			'title'		=> $obj->title,
			'excerpt'	=> $obj->description,
			'content'	=> $obj->content,
			'url'		=> $obj->alias,
			'postdate'	=> date('Y-m-d H:i:s', $obj->dateline),
			'password'	=> $obj->readpassword,
			'visible'	=> $obj->visible,
			'comment_count'	=> $obj->comments,
			'view_count'	=> $obj->views,
			'allow_trackback'	=> !$obj->closetrackback,
			'allow_comment'		=> !$obj->closecomment,
			'allow_view'		=> $obj->visible
		);
	}
	function getComments($article) {
		global $db, $db_prefix, $dbname;
		$id = intval($article->oldid);
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}comments WHERE articleid=$id";
		$result = mysql_query($sql, $db);
		$arr = array();
		while($row=mysql_fetch_object($result)) {
			$arr[] = (object) array(
				'oldid'		=> $row->commentid,
				'articleid'	=> $row->articleid,
				'author'	=> $row->author,
				'url'		=> $row->url,
				'content'	=> $row->content,
				'time'		=> date('Y-m-d H:i:s', $row->dateline),
				'ip'		=> $row->ipaddress,
				'visible'	=> $row->visible
			);
		}
		return $arr;
	}
	function getTrackbacks($article) {
		global $db, $db_prefix, $dbname;
		$id = intval($article->oldid);
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}trackbacks WHERE articleid=$id";
		$result = mysql_query($sql, $db);
		$arr = array();
		while($row=mysql_fetch_object($result)) {
			$arr[] = (object) array(
				'oldid'		=> $row->trackbackid,
				'articleid'	=> $row->articleid,
				'title'		=> $row->title,
				'excerpt'	=> $row->excerpt,
				'url'		=> $row->url,
				'time'		=> $row->dateline,
				'ip'		=> $row->ipaddress,
				'visible'	=> $row->visible
			);
		}
		return $arr;
	}
	function getLinks() {
		global $db, $db_prefix, $dbname;
		$sql = "SELECT * FROM {$dbname}.{$db_prefix}links ORDER BY displayorder ASC";
		$result = mysql_query($sql, $db);
		$arr = array();
		while($row=mysql_fetch_object($result)) {
			$arr[] = (object) array(
				'oldid'		=> $row->linkid,
				'name'		=> $row->name,
				'url'		=> $row->url,
				'desc'		=> $row->note,
				'visible'	=> $row->visible
			);
		}
		return $arr;
	}
}