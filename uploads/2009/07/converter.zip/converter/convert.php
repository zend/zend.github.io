<?php
( isset($_REQUEST['from']) && isset($_REQUEST['to']) ) || die('Accept POST only.');

header('Content-type: text/html; charset=utf-8');
$from = preg_replace("/[^a-z0-9\.\-]/i", '', $_REQUEST['from']);
$to = preg_replace("/[^a-z0-9\.\-]/i", '', $_REQUEST['to']);

//var_dump($_REQUEST);
include "from/$from";
$objFrom = new BlogFrom();

include "to/$to";
$objTo = new BlogTo();
/*
// Get blog settings
$settings = $objFrom->getSettings();
$settings->name = htmlentities($settings->name, ENT_QUOTES);
echo '更新博客名和简介。<hr />';
$objTo->setSettings($settings);

// Get users
$users = $objFrom->getUsers();
$i = $objTo->setUsers($users);
var_dump($i);
echo '转换用户完成。<hr />';

// Get categories
$cates = $objFrom->getCates();
$i = $objTo->setCates($cates);
var_dump($i);
echo '转换类别完成。<hr />';

// Get articles list, includes: comments, trackbacks
while($article = $objFrom->getNextArticle()) {
	echo $article->oldid . ': ' . $article->title . '<hr />';
	$objTo->setArticle($article);
	$comments = $objFrom->getComments($article);
	$objTo->setComments($comments);
	unset($comments);
	$trackbacks = $objFrom->getTrackbacks($article);
	$objTo->setTrackbacks($trackbacks);
	unset($trackbacks);
}
*/
$objTo->updateCateCache();
/*
// Get blogroll data
$links = $objFrom->getLinks();
$count = $objTo->setLinks($links);

var_dump($i);
echo '转换友情链接完成。<hr />';
*/