<?php
$from = get_modules('from');
$to = get_modules('to');

function get_modules($type) {
	$d = dir($type);
	$arr = array();
	while( false !== ($f = $d->read()) ) {
		if (substr($f, -4)!=='.php') continue;
		$name = get_name($type, $f);
		$arr[$f] = $name;
	}
	return $arr;
}

function get_name($type, $mod) {
	$file = file_get_contents($type .'/'.$mod);
	preg_match("#/\* Name: (.+) \*/#", $file, $out);
	return $out[1];
}
?>
<h1>Blog Converter</h1>
<form method="post" action="convert.php" target="conv">
	From:
	<select name="from">
	<?php
	foreach($from as $k=>$v) {
	?>
		<option value="<?php echo $k; ?>"><?php echo $v; ?></option>
	<?php
	}
	?>
	</select>

	To:
	<select name="to">
	<?php
	foreach($to as $k=>$v) {
	?>
		<option value="<?php echo $k; ?>"><?php echo $v; ?></option>
	<?php
	}
	?>
	</select>
	<input type="submit" value="Convert!" />
</form>
<iframe name="conv" width="500" height="300" frameborder='0'></iframe>