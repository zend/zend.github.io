<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh" lang="zh" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Sphinx Search</title>
</head>

<body>
<form method="post" action="">
	<input type="text" name="q" value="<?php echo $_REQUEST['q'] ?>" />
	<input type="submit" />
</form>

<?php
$q = $_REQUEST['q'];

//$q = '中文';

$index = 'test1';

$client = new SphinxClient();
$client->SetServer('192.168.0.251', 3312);
$client->SetMatchMode(SPH_MATCH_ALL);
$res = $client->Query($q, $index);

//print_r($res);

$keys = '';
foreach($res['words'] as $k=>$v) {
	$keys .= "<a href='?q=$k'>$k</a> ";
}
//$keys = join( ', ', array_keys($res['words']) );

echo "搜索 $keys 有{$res['total_found']}项结果，费时{$res['time']}秒。<hr />";

if ( $res['matches'] ) {
	$ids = array();
	foreach( $res['matches'] as $key=>$value ) {
		$ids[] = $key;
	}

	$sql = "SELECT * FROM test.documents WHERE id IN (" . join(',', $ids) . ")";

	$db = mysql_connect("localhost", "test", "testtest");

	mysql_query("SET NAMES utf8");

	$query = mysql_query($sql);

	//var_dump($sql);

	while( $row = mysql_fetch_object($query) ) {
		echo "[$row->id] $row->title $row->content <hr />\n";
	}

	mysql_close($db);
} else {
	echo '无结果。';
}
?>

</body>
</html>